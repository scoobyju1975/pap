<?php
/**
* The main template file
*
* This is the most generic template file in a WordPress theme
* and one of the two required files for a theme (the other being style.css).
* It is used to display a page when nothing more specific matches a query.
* E.g., it puts together the home page when no home.php file exists.
*
* @link https://codex.wordpress.org/Template_Hierarchy
*
* @package WP_Plug_And_Play
*/
get_header(); ?>
<section id="primary" class="content-area col-sm-12 col-md-12 col-lg-12">
	<div class="home-search">
		<form role="search" method="get" class="search-form" action="<?php echo home_url( '/' ); ?>">
			<label>
				<input type="search" class="search-field"
				placeholder="<?php echo esc_attr_x( 'Find a Specialist', 'placeholder' ) ?>"
				value="<?php echo get_search_query() ?>" name="s" />
			</label>
		</form>
	</div>
	</section><!-- #primary -->
	<?php
	get_footer('home');